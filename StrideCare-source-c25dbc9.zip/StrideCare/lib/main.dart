import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/stridecare_app.dart';

void main() => runApp(const ProviderScope(child: StrideCareApp()));
