# StrideCare handoff through Phase 3

Start with AGENTS.md for the product specification, DESIGN.md for the visual rules and README.md for the build instructions. This is a working-tree snapshot. It includes the later pairing and Firebase work already imported by the app so the project can build as delivered.

## Run the website

Extract the entire folder, open the directory containing pubspec.yaml in VS Code, install Flutter 3.50.1 and Chrome, then run:

```sh
flutter pub get
flutter run -d chrome
```

The default patient preview opens directly in practice mode. A fresh browser profile begins with language selection. Complete onboarding with fictional contacts, then pair the practice cane from Today. Leave the app open to observe automatic detection and a saved walk. The emulator build exposes sign-in at /?view=connected. See backend/README.md for the separate Firebase workflow.

## Implementation map

| Phase | Implemented | Remaining or unverified |
| --- | --- | --- |
| 1 — Foundation | Flutter web, Android and iOS project files, Riverpod, Drift schema and generated bindings, bundled fonts, English/Hindi/Punjabi resources, design tokens and navigation | Native-speaker review and physical-device verification |
| 2 — Patient and walks | Onboarding with two distinct required contacts, Today, mock telemetry, automatic live sessions, estimated pace, recovery scoring and progress charts | Contact consent delivery, background walk notifications, real-device calibration and clinical validation |
| 3 — Wellness and safety | Two meal ideas and a daily check-in, a breathing approval gate, medication entries with taken times, mobile reminder integration, simulated fall countdown and contact stages, local family summary and weekly PDF | Stage- and injury-specific reviewed content, adaptive guided routines, medication streaks, device-tested reminders, real emergency SMS, call, location and acknowledgement delivery |

## Follow one walk through the code

1. lib/main.dart selects the offline or connected experience. lib/app/stridecare_app.dart routes the patient into onboarding or the app shell.
2. lib/features/cane supplies the simulated grip, load and step streams behind CaneService. lib/features/walk detects a session, drives Live Walk and completes its summary. Walking starts automatically.
3. lib/features/progress/daily_metrics.dart saves sessions and aggregates daily metrics. lib/storage/schema.drift defines the persistent records. lib/features/progress/weekly_report.dart creates the PDF.
4. lib/features/wellness, medicine and safety contain the Phase 3 features. Keep habits medication-only. Cane load measures support on the cane. Estimated pace is a trend. Practice fall stages operate locally.
5. lib/features/cloud, firebase.json and backend contain the optional shared-record implementation. backend/datasets contains synthetic test walks. The local practice dashboard and authenticated clinician dashboard have separate entry paths.

Run flutter analyze and flutter test after changes. test/ contains detector, mock walk, onboarding, navigation, database, recovery, report and sync tests. The Chrome Firebase workflow test requires the seeded emulators and its explicit command in backend/README.md.
